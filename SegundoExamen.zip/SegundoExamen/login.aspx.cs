﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace SegundoExamen
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void bingresar_Click(object sender, EventArgs e)
        {
            usuario.setLogin_Usuario(tusuario.Text);
            usuario.setClave_Usuario(tclave.Text);

            string s = System.Configuration.ConfigurationManager.ConnectionStrings["VeterinariaConnectionString"].ConnectionString;

            SqlConnection conexion = new SqlConnection(s);  
            conexion.Open();

            SqlCommand comando = new SqlCommand(" select Login_Usuario,Clave_Usuario from Mae_Usuarios where Login_Usuario = '" + usuario.getLogin_Usuario() + "'and Clave_Usuario = '" + usuario.getClave_Usuario() + "'", conexion);

            SqlDataReader registro = comando.ExecuteReader();

            if (registro.Read())
            {
                Response.Redirect("webforminicial.aspx");
            }
            else {
                mensaje.Text = "******usuario o contrasena incorrecta****** ";
            
            }


            conexion.Close();


        }




    }
}