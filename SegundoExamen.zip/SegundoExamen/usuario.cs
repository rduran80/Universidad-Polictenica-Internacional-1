﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SegundoExamen
{
    public class usuario
    {
        private static string Login_Usuario { get; set; }
        private static string Clave_Usuario { get; set; }
        private static string Nombre_Usuario { get; set; }


        public static string getLogin_Usuario()
        {
            return Login_Usuario;

        }
        public static void setLogin_Usuario(string login)
        {
            Login_Usuario = login;

        }

        public static string getClave_Usuario()
        {
            return Clave_Usuario;

        }
        public static void setClave_Usuario(string Clave)
        {
            Clave_Usuario = Clave;
        
        }




    }
}