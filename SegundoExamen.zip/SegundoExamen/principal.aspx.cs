﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SegundoExamen
{
    public partial class principal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void bagregar_Click(object sender, EventArgs e)
        {
            SqlDataSource1.Insert();

        }

        protected void bborrar_Click(object sender, EventArgs e)
        {
            SqlDataSource1.Delete();
        }

        protected void bactualizar_Click(object sender, EventArgs e)
        {
            SqlDataSource1.Update();    
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }
}