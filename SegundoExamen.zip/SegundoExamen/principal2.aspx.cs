﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SegundoExamen
{
    public partial class principal2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void bagregar_Click(object sender, EventArgs e)
        {
            SqlDataSource2.Insert();
        }

        protected void bborrar_Click(object sender, EventArgs e)
        {
            SqlDataSource2.Delete();
        }

        protected void bactualizar_Click(object sender, EventArgs e)
        {
            SqlDataSource2.Update();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }

        protected void SqlDataSource2_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }
    }
}